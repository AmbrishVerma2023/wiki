#!/bin/bash

read -p 'Enter your Application Name: ' appname

read -p 'Enter your Environment (dev, itg, uat or prod): ' environment

dnssuffix=".dc02.its.hpecorp.net"

# certificate details for herenow script (configurable)
COUNTRY="US"                # 2 letter country-code
STATE="California"            # state or province name
LOCALITY="Palo Alto"        # Locality Name (e.g. city)
ORGNAME="Hewlett Packard Enterprise Company" # Organization Name (eg, company)
ORGUNIT=""                  # Organizational Unit Name (eg. section)
COMMONNAME="$appname-$environment$dnssuffix"
EMAIL=""    # certificate's email address
# optional extra details
CHALLENGE=""                # challenge password
COMPANY="Hewlett Packard Enterprise Company"                  # company name

if [ $environment = prod ] 
then 
	dnssuffix=".dc01.its.hpecorp.net"
	COMMONNAME="$appname$dnssuffix"
fi

openssl genrsa -out $appname-$environment.key 2048


cat <<__EOF__ | openssl req -newkey rsa:2048 -nodes -keyout $appname-$environment.key -out $appname-$environment.csr
$COUNTRY
$STATE
$LOCALITY
$ORGNAME
$ORGUNIT
$COMMONNAME
$EMAIL
$CHALLENGE
$COMPANY
__EOF__

printf  "\n\n$appname-$environment.csr generated successfully. Please apply for internal or external certificate"

printf  "\n\nCommon Name of your certificate is : $COMMONNAME"

printf  "\n\nSubmit your request @ https://myitsupport.ext.hpe.com/myITsupport/ITSArticle?ArticleNumber=000001599"