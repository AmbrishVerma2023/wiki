# ELK-Template
This repo contains template for a basic ELK- Elasticsearch, Logstash & Kibana stack deployment.

Let's look at each component

1. [Elasticsearch](https://github.hpe.com/hpe/elk-template/tree/main/elasticsearch):

- This folder contains [quickstart.yaml](https://github.hpe.com/hpe/elk-template/blob/main/elasticsearch/quickstart.yaml) that uses elasticsearch with Kind `Elasticsearch` CRD.
- CRD will deploy,
  - A Pod that runs Elasticsearch.
  - A Service that exposes the deploy Elasticsearch.

2. [Kibana](https://github.hpe.com/hpe/elk-template/tree/main/kibana):

- This folder contains [kibana.yaml](https://github.hpe.com/hpe/elk-template/blob/main/kibana/kibana.yml) that uses elasticsearch with Kind `Kibana` CRD.
- CRD will deploy,
  - A Pod that runs Kibana.
  - A Service that exposes the deploy Kibana.
- Next file [kibana-istio.yaml](https://github.hpe.com/hpe/elk-template/blob/main/kibana/kibana-istio.yaml) 
  - This file will deploy the Istio components Gateway, Virtual Service & Destination Rule to make Kibana accessible. 
  - Please refer to this [wiki](https://github.hpe.com/CaaSonHPE/Wiki/wiki/HPE-IT-Ezmeral-Container-Platform#understanding-kubernetes-istio-ingress) for more information about the Istio components.

3. [Logstash](https://github.hpe.com/hpe/elk-template/tree/main/logstash):

- This folder contains [logstash.yaml](https://github.hpe.com/hpe/elk-template/blob/main/logstash/logstash.yaml) deployment that runs Logstash.
- A [Service](https://github.hpe.com/hpe/elk-template/blob/main/logstash/logstash-service.yaml) that exposes the deploy Kibana.
- A Config Map [logstash-cm.yaml](https://github.hpe.com/hpe/elk-template/blob/main/logstash/logstash-cm.yaml) that contains the pipeline conf for Logstash. 
- Next file [logstash-istio.yaml](https://github.hpe.com/hpe/elk-template/blob/main/logstash/logstash-istio.yaml) 
  - This file will deploy the Istio components Gateway, Virtual Service & Destination Rule to make Logstash accessible to receive logs. 

Now let's start deploying the stack.

1. Clone the repo and Navigate to the repos root folder
`git clone https://github.hpe.com/hpe/elk-template.git`
`cd elk-template/`

2. Deploy Elasticsearch
`kubectl apply -f elasticsearch/quickstart.yaml -f elasticsearch/es-istio.yaml`

Verify that the pod and services are created.
`kubectl get po,svc`

Test elasticsearch locally in CLI to verify it is accessible,

`PASSWORD=$(kubectl -n <replace-with-your-namespace> get secret quickstart-es-elastic-user -o go-template='{{.data.elastic | base64decode}}')`
`curl -u "elastic:$PASSWORD" -k "https://quickstart-es-http:9200"`

Using Browser,

Get elastic user's password,
`kubectl -n <replace-with-your-namespace> get secret quickstart-es-elastic-user -o go-template='{{.data.elastic | base64decode}}'` 
`kubectl port-forward quickstart-es-default-0 9200:9200`

From your local Browser hit `https://localhost:9200` and provide the user as `elastic` and password from earlier step to login.

3. Deploy Kibana
`kubectl apply -f kibana/kibana.yml -f kibana/kibana-istio.yml`

Get the Kibana pod name using `kubectl get po` and look for a pod with kibana in it's name.
You can test the Kibana accessibility using port-forwarding similiar to elasticsearch i.e., `kubectl port-forward <kibana-pod-name> 9200:9200`

Add certificate to make the URL mentioned in istio configs accessible

- Create certificate using the instructions available in this [doc](https://github.hpe.com/CaaSonHPE/Wiki/blob/master/SSL%20Creation%20for%20App%20teams-%20CaaS.DOCX).
- Add them to your namespace with 1st [step](https://github.hpe.com/CaaSonHPE/Wiki/wiki/HPE-IT-Ezmeral-Container-Platform#example-configuration-for-tls-passthrough-at-the-istio-gateway) of this instruction and ensure to create the cert in the same name as your credential in your istio gateway yaml config.

Once above step is complete, you should be able to access Kibana over the DNS endpoint avaiable.

In case you don't have a DNS, please raise a request to get it created with the DNS aliases corresponding to your environment as documented [here](https://github.hpe.com/CaaSonHPE/Wiki/wiki/HPE-IT-Ezmeral-Container-Platform#creating-a-dns-entry-for-application).

5. Deploy Logstash

-Add the config map that contains Logstash pipeline & plugin conf
`kubectl apply -f logstash/logstash-cm.yaml`

-Apply logstash deployment and service 
`kubectl apply -f logstash/logstash.yaml -f logstash/logstash-service.yaml`

At this point your logstash is accessible locally within the kubernetes cluster.
You can test it with port forwarding similiar to Kibana

Get the Logstash pod name using `kubectl get po` and look for a pod with Logstash in it's name.
You can test the Kibana accessibility using port-forwarding similiar to elasticsearch i.e., `kubectl port-forward <logstash-pod-name> 5044:5044`

From another CLI run `curl -k --noproxy "*" -X POST https://localhost:5044 -d '{"message":"hellofromlocal"}'`
This return a `ok` in response, we can check if the data reached Elasticsearch in later steps.

Generate certificate for Logstash similiar to how we did for Kibana and add them to Istio system namespace by getting in touch with Platform admins via [slack](https://hpe-internal.slack.com/archives/C02298P7KA7).

Once the certificate is added, apply the Istio configs,

`kubectl apply -f logstash/logstash-istio.yaml`

Now the logstash should return a 'ok' if access it on browser.

Test sending logs to Logstash.

Let's view our Kibana UI and add a Index pattern for the logs we sent

Navigate from the left pane -> Stack Management -> Kibana -> Index Patterns -> Create index pattern

Type in Logstash- , as this is the index we pushed in our logstash conf and click create index pattern from the bottom.

![image](https://media.github.hpe.com/user/40319/files/f4793ab6-75ef-474f-881b-d81a0124bb23)

We already two indices in this example,

![image](https://media.github.hpe.com/user/40319/files/3ac20e75-dbd7-4492-a69f-41860bd2c9e1)

Let's head over to Analytics -> Discover from Left Pane, then choose the index pattern we just created,

![image](https://media.github.hpe.com/user/40319/files/861ec8ed-2d73-4ca5-acd6-507b37cb84c1)

We have now successfuly configured ELK stack on ECP with CRD for ElasticSearch and Kibana, exposed them with a URL and tested sending logs.

Thank you !

