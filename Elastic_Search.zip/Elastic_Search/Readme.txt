HPE ECP ITG environmnet in CoLo2 is for hosting NON-PROD workloads such as DEV/ITG/UAT applications.

ECP Version: 5.2
Kubernetes Version: 1.18.6
Istio Version: 1.7.1

1. Login to HPE ECP using SAML/SSO
2. Install Kubectl
The Kubernetes command-line tool, kubectl, allows you to run commands against Kubernetes clusters. You can use kubectl to deploy applications, inspect and manage cluster resources, and view logs.
	1. Download the kubectl plugin to a folder
	2. Configure this folder path as Environment variable
	3. Verify the installation using this command through cmd: kubectl version --client
Response: 
Client Version: version.Info{Major:"1", Minor:"20", GitVersion:"v1.20.11", GitCommit:"27522a29febbcc4badac257763044d0d90c11abd", GitTreeState:"clean", BuildDate:"2021-09-15T19:21:44Z", GoVersion:"go1.15.15", Compiler:"gc", Platform:"windows/amd64"}	
3. Install HPE Kubectl plugin before connecting to the Kubernettes cluster
	1. Download the binary to the folder which is defined as the environment variable
	2. Download Kubeconfig and paste to the path where environment variable is set. 
	3. Set the environment variable using the command: set KUBECONFIG=C:\Users\vermaamb\Desktop\Work\Elastic_Search\emdm_kubeconfig
	4. Verify the installation using the command: kubectl hpecp version
response: 
{
 "major": "3",
 "minor": "4",
 "gitVersion": "v3.4-14",
 "gitCommit": "aed15d713a944931d79f5702cdda8026ee88fdf1",
 "gitTreeState": "clean",
 "buildDate": "2020-08-31 17:18:57",
 "goVersion": "go1.14.6",
 "compiler": "gc",
 "platform": "windows/amd64"
}	
	5. Validate the configuration set using: kubectl config view
response: 
apiVersion: v1
clusters:
- cluster:
    insecure-skip-tls-verify: true
    server: https://dashboard-ecp-itg.dc02.its.hpecorp.net:9500
  name: COLO2-ITG-ECP-ECP-ITG
contexts:
- context:
    cluster: COLO2-ITG-ECP-ECP-ITG
    namespace: emdm
    user: COLO2-ITG-ECP-ambrish.verma@hpe.com
  name: COLO2-ITG-ECP-ECP-ITG-EMDM-ambrish.verma@hpe.com
current-context: COLO2-ITG-ECP-ECP-ITG-EMDM-ambrish.verma@hpe.com
kind: Config
preferences: {}
users:
- name: COLO2-ITG-ECP-ambrish.verma@hpe.com
  user:
    exec:
      apiVersion: client.authentication.k8s.io/v1beta1
      args:
      - hpecp
      - authenticate
      - dashboard-ecp-itg.dc02.its.hpecorp.net:8080
      - --hpecp-user=ambrish.verma@hpe.com
      - --hpecp-token=/api/v2/session/3faa0423-533b-4a71-a0e0-008788a5ef5a
      - --hpecp-token-expiry=1662198009
      - --force-reauth=false
      - --insecure-skip-tls-verify=true
      command: kubectl
      env: null
      provideClusterInfo: false
	  
------------------------------------------------------------------------------------------------------------------------------	
Steps to deploy the Elastic Stack: 

1. Clone the repo and Navigate to the repos root folder git clone https://github.hpe.com/hpe/elk-template.git cd elk-template/

2. Deploy Elasticsearch kubectl apply -f elasticsearch/quickstart.yaml -f elasticsearch/es-istio.yaml

3. Verify that the pod and services are created. kubectl get po,svc 	  

4. Test elasticsearch locally in CLI to verify it is accessible using the below command(this will fetch the password): 
		kubectl get secret quickstart-es-elastic-user -n emdm -o jsonpath='{.data.elastic}'
		Password(encoded): 'Nkh0MnRTcmkxaWcyMjhuOFk0VThNejJ3'
		Decode the password:
			1. copy the encoded pwd in a text file(enc_pwd.txt) and place it in the same location as the cmd prompt
			2. command: certutil -decode enc_pwd.txt dcd_pwd.txt
			3. content of dcd_pwd.txt is the password
5. Execute the command to perform port forwarding: kubectl port-forward quickstart-es-default-0 9200:9200
6. On the browser, hit the url: https://localhost:9200 and login with user: elastic and pwd from 4.3 above
	response: 
{
  "name" : "testelasticsearch-es-default-0",
  "cluster_name" : "testelasticsearch",
  "cluster_uuid" : "xrMPVzT0TkmAtjoUBtQPDQ",
  "version" : {
    "number" : "8.4.0",
    "build_flavor" : "default",
    "build_type" : "docker",
    "build_hash" : "f56126089ca4db89b631901ad7cce0a8e10e2fe5",
    "build_date" : "2022-08-19T19:23:42.954591481Z",
    "build_snapshot" : false,
    "lucene_version" : "9.3.0",
    "minimum_wire_compatibility_version" : "7.17.0",
    "minimum_index_compatibility_version" : "7.0.0"
  },
  "tagline" : "You Know, for Search"
}


command: kubectl get elasticsearches
this shows the elasticsearch health status in green:
NAME                HEALTH    NODES   VERSION   PHASE             AGE
quickstart          unknown           7.15.1    ApplyingChanges   309d
testelasticsearch   green     1       8.4.0     Ready             3h15m
--------------------------------------------------------------------------------------------------------------------------------


useful commands: 
kubectl get resourcequota -n emdm

kubectl apply -f .\elastic_stack_github\elk-template\logstash\Logstash_v8.yml

kubectl delete -f .\elastic_stack_github\elk-template\logstash\Logstash_v7.yml




	
	  
	  